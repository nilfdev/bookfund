<?php return array('dependencies' => array('wp-polyfill'), 'version' => '0f5555cd049737c938d2');
