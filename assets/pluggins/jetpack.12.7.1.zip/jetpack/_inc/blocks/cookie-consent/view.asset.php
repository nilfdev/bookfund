<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '9584e69182ca362921f5');
