<?php return array('dependencies' => array('wp-polyfill'), 'version' => '7cb1d6e02d35d81335f4');
