<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'd5fe06582b79a63f3932');
