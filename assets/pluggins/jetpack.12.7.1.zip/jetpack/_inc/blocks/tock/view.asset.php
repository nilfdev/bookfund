<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'b2d2622f7ecd0d31a8bc');
