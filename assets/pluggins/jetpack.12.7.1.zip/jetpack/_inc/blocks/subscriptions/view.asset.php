<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'e5b50879e1032ccb0008');
