<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '9f21d166d7749f58d9c4');
