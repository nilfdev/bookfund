<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '1e427ced618bf331a0bd');
