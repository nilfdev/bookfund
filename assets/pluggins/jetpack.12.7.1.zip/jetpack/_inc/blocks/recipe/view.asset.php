<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '80d0cc15a92ebf2c044f');
