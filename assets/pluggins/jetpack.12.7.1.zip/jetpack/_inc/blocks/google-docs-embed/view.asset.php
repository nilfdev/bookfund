<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'a74f54ad582014831109');
