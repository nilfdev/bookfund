<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'a7f6bddced55dabbbe4e');
