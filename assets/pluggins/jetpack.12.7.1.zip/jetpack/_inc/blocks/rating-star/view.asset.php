<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'dd39a8895a338aa66e93');
