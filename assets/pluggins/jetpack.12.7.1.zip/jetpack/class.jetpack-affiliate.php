<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * Deprecated since 8.1.0.
 * Functionality moved to the automattic/jetpack-partner package.
 *
 * @package automattic/jetpack
 */
